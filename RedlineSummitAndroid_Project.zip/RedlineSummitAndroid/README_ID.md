# Redline Summit — Android project

Project Android Studio untuk membungkus mini game HTML menjadi aplikasi Android offline.

## Membuat APK
1. Ekstrak `RedlineSummitAndroid.zip`.
2. Buka Android Studio, pilih **Open**, lalu pilih folder `RedlineSummitAndroid`.
3. Tunggu Gradle sync selesai. Android Studio mungkin perlu mengunduh Android Gradle Plugin dan Android SDK Platform 35.
4. Untuk APK yang bisa dipasang: pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Setelah build sukses, pilih tautan **locate** di notifikasi. APK biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.
6. Pindahkan APK ke ponsel Android dan buka untuk menginstal. Android mungkin meminta izin untuk memasang aplikasi dari sumber tersebut.

## Detail
- Nama aplikasi: Redline Summit
- Application ID: `com.redline.summit`
- Minimum Android: Android 6.0 (API 23)
- Orientasi: landscape
- Game dimuat dari aset lokal, sehingga permainan tidak membutuhkan koneksi internet setelah terpasang.

Catatan: paket ini adalah **source project Android**, bukan file APK yang sudah dikompilasi. Lingkungan pembuatan file saat ini tidak memiliki Android SDK/Gradle yang diperlukan untuk menghasilkan APK siap instal secara langsung.
